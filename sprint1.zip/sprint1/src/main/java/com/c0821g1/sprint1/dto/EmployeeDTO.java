package com.c0821g1.sprint1.dto;

public class EmployeeDTO {
}

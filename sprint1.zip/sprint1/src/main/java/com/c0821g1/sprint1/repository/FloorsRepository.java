package com.c0821g1.sprint1.repository;

import com.c0821g1.sprint1.entity.floor.Floors;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FloorsRepository extends JpaRepository<Floors,Integer> {
}

package com.c0821g1.sprint1.service;

public interface SpaceStatusService {
}

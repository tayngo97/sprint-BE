package com.c0821g1.sprint1.service.impl;

import com.c0821g1.sprint1.service.ContractService;

public class ContractServiceImpl implements ContractService {
}

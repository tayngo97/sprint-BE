package com.c0821g1.sprint1.service.impl;

import com.c0821g1.sprint1.service.EmployeeService;
import org.springframework.stereotype.Service;


@Service
public class EmployeeServiceImpl implements EmployeeService {
}

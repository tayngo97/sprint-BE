package com.c0821g1.sprint1.service.impl;

import com.c0821g1.sprint1.service.FloorsService;

public class FloorServiceImpl implements FloorsService {
}

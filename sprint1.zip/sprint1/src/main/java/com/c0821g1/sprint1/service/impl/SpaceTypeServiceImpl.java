package com.c0821g1.sprint1.service.impl;

import org.springframework.stereotype.Service;

@Service
public class SpaceTypeServiceImpl {
}

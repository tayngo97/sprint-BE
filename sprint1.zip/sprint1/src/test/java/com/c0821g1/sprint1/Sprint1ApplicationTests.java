package com.c0821g1.sprint1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sprint1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
